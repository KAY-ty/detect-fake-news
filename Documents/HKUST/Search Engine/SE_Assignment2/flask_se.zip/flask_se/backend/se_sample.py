'''
Author: JasonYU
Date: 2020-10-02 09:17:33
LastEditTime: 2020-10-04 10:00:43
FilePath: \SE\flask_se\backend\se_sample.py
'''



def search_api(query):
    """
    query:[string] 
    return: list of dict, each dict is a paper record of the original dataset
    """
    raise raiseNotImplementedError("You need implement this function")


if __name__ == "__main__":
    search_api("knowledge graph")